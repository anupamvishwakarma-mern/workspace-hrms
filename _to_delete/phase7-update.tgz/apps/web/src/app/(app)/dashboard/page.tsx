'use client';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useAuth } from '@/components/auth';
import {
  Alert,
  Card,
  CardTitle,
  PageHeader,
  Skeleton,
  Table,
  Td,
  Th,
} from '@/components/ui/display';
import { api } from '@/lib/api';
import { userMessage } from '@/lib/errors';
import type { Dashboard } from '@/lib/types';
import { formatDate } from '@/lib/utils';

export default function DashboardPage() {
  const { active } = useAuth();
  const q = useQuery({
    queryKey: ['dashboard', active?.tenantId],
    queryFn: async () => (await api.get<Dashboard>('/reports/dashboard')).data,
    refetchInterval: 60_000,
  });

  if (q.isPending)
    return (
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }, (_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  if (q.isError) return <Alert tone="danger">{userMessage(q.error)}</Alert>;
  const d = q.data;
  const t = d.today;
  const stats: { label: string; value: number; hint?: string }[] = [
    {
      label: 'Present',
      value: t.present + t.halfDay,
      hint: t.halfDay ? `${t.halfDay} half day` : undefined,
    },
    { label: 'Working now', value: t.workingNow },
    { label: 'Not checked in yet', value: t.notYetIn },
    { label: 'Late today', value: t.lateToday },
    { label: 'Absent', value: t.absent },
    { label: 'On leave', value: t.onLeave },
    { label: 'Holiday / weekly off', value: t.holiday + t.weeklyOff },
    { label: 'No shift assigned', value: t.unscheduled },
  ];
  const chartData = d.trend.map((r) => ({ ...r, label: r.date.slice(5) }));

  return (
    <>
      <PageHeader
        title="Dashboard"
        description={`${formatDate(d.workDate)} · ${d.timezone} · ${d.headcount} ${d.scope === 'TEAM' ? 'people in your team' : 'employees'}`}
      />
      {d.pending && (d.pending.corrections > 0 || d.pending.exceptions > 0) ? (
        <div className="mb-4">
          <Alert tone="warn">
            <Link href="/approvals" className="font-semibold underline">
              {d.pending.corrections} correction{d.pending.corrections === 1 ? '' : 's'} and{' '}
              {d.pending.exceptions} location approval{d.pending.exceptions === 1 ? '' : 's'}{' '}
              waiting for review
            </Link>
          </Alert>
        </div>
      ) : null}

      <section aria-label="Today" className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardTitle>{s.label}</CardTitle>
            <p className="mt-1 text-3xl font-bold tabular-nums">{s.value}</p>
            {s.hint ? <p className="text-xs text-muted">{s.hint}</p> : null}
          </Card>
        ))}
      </section>

      <Card className="mt-4">
        <CardTitle>Last 14 days</CardTitle>
        <div
          className="mt-3 h-72"
          role="img"
          aria-label="Stacked bars of present, half day and absent employees for each of the last 14 days"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ left: -16, right: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: 'var(--muted)', fontSize: 12 }} />
              <YAxis allowDecimals={false} tick={{ fill: 'var(--muted)', fontSize: 12 }} />
              <Tooltip
                contentStyle={{
                  background: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: 8,
                  color: 'var(--foreground)',
                }}
              />
              <Legend />
              <Bar dataKey="present" name="Present" stackId="a" fill="var(--chart-1)" />
              <Bar dataKey="halfDay" name="Half day" stackId="a" fill="var(--chart-2)" />
              <Bar dataKey="absent" name="Absent" stackId="a" fill="var(--chart-3)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <details className="mt-3 text-sm">
          <summary className="cursor-pointer text-muted">View as table</summary>
          <div className="mt-2">
            <Table>
              <thead>
                <tr>
                  <Th>Date</Th>
                  <Th>Present</Th>
                  <Th>Half day</Th>
                  <Th>Absent</Th>
                  <Th>Late</Th>
                </tr>
              </thead>
              <tbody>
                {d.trend.map((r) => (
                  <tr key={r.date}>
                    <Td>{formatDate(r.date)}</Td>
                    <Td>{r.present}</Td>
                    <Td>{r.halfDay}</Td>
                    <Td>{r.absent}</Td>
                    <Td>{r.late}</Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </details>
        <p className="mt-2 text-xs text-muted">
          Past days with no punches count as absent only when the person had a shift that day.
        </p>
      </Card>
    </>
  );
}
