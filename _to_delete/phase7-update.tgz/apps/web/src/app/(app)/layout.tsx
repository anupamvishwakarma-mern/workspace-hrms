'use client';
import {
  Building2,
  CalendarClock,
  CalendarDays,
  CheckSquare,
  History,
  Plane,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  MapPin,
  Menu,
  Settings,
  Users,
  FileBarChart,
  type LucideIcon,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState, type ReactNode } from 'react';
import { useAuth } from '@/components/auth';
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/form';
import { Skeleton } from '@/components/ui/display';
import { cn } from '@/lib/utils';

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  perms: string[];
}
export const NAV: NavItem[] = [
  {
    href: '/dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    perms: ['attendance:read:all', 'attendance:read:team'],
  },
  {
    href: '/attendance',
    label: 'Attendance',
    icon: ClipboardList,
    perms: ['attendance:read:all', 'attendance:read:team'],
  },
  {
    href: '/approvals',
    label: 'Approvals',
    icon: CheckSquare,
    perms: ['attendance:review:all', 'attendance:review:team'],
  },
  {
    href: '/reports',
    label: 'Reports',
    icon: FileBarChart,
    perms: ['attendance:read:all', 'attendance:read:team'],
  },
  {
    href: '/employees',
    label: 'Employees',
    icon: Users,
    perms: ['employee:read:all', 'employee:read:team', 'employee:read:basic'],
  },
  {
    href: '/leave',
    label: 'Leave',
    icon: Plane,
    perms: ['leave:review:all', 'leave:review:team', 'leave:manage'],
  },
  { href: '/departments', label: 'Departments', icon: Building2, perms: ['department:manage'] },
  { href: '/shifts', label: 'Shifts', icon: CalendarClock, perms: ['shift:manage'] },
  { href: '/locations', label: 'Locations', icon: MapPin, perms: ['location:manage'] },
  { href: '/holidays', label: 'Holidays', icon: CalendarDays, perms: ['holiday:manage'] },
  { href: '/audit', label: 'Audit log', icon: History, perms: ['audit:read'] },
  { href: '/settings', label: 'Settings', icon: Settings, perms: ['tenant:update'] },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const { status, active, can, memberships, selectCompany, signOut, email, retry } = useAuth();
  const router = useRouter();
  const path = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (status === 'signedOut' || status === 'needsCompany') router.replace('/login');
  }, [status, router]);
  useEffect(() => setOpen(false), [path]);

  if (status === 'offline')
    return (
      <Center>
        <h1 className="text-xl font-bold">Cannot reach the server</h1>
        <p className="text-sm text-muted">
          You are still signed in. Check your connection and try again.
        </p>
        <Button onClick={retry}>Try again</Button>
      </Center>
    );
  if (status === 'noAccess')
    return (
      <Center>
        <h1 className="text-xl font-bold">No company access</h1>
        <p className="text-sm text-muted">
          Your account is not an active member of any company. Contact your administrator.
        </p>
        <Button variant="secondary" onClick={() => void signOut()}>
          Sign out
        </Button>
      </Center>
    );
  if (status !== 'ready' || !active)
    return (
      <div className="p-8">
        <Skeleton className="h-8 w-48" />
      </div>
    );

  const items = NAV.filter((n) => can(...n.perms));
  // Cosmetic: a typed-in URL for a page the role has no menu entry for. The API enforces access regardless.
  const current = NAV.find((n) => path === n.href || path.startsWith(`${n.href}/`));
  const blocked = !!current && !can(...current.perms);
  // Web is for people who administer or manage. Plain employees use the mobile app.
  const isStaff = can('attendance:read:all', 'attendance:read:team');

  const nav = (
    <nav aria-label="Main" className="flex flex-col gap-1">
      {items.map((n) => {
        const on = path === n.href || path.startsWith(`${n.href}/`);
        return (
          <Link
            key={n.href}
            href={n.href}
            aria-current={on ? 'page' : undefined}
            className={cn(
              'flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent',
              on && 'bg-accent text-primary',
            )}
          >
            <n.icon className="h-4 w-4" aria-hidden /> {n.label}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen md:grid md:grid-cols-[15rem_1fr]">
      <aside
        className={cn('border-r border-border bg-card p-4 md:block', open ? 'block' : 'hidden')}
      >
        <p className="mb-4 hidden text-lg font-bold text-primary md:block">Workforce</p>
        {memberships.length > 1 ? (
          <div className="mb-4">
            <label htmlFor="company" className="mb-1 block text-xs text-muted">
              Company
            </label>
            <Select
              id="company"
              value={active.tenantId}
              onChange={(e) => selectCompany(e.target.value)}
            >
              {memberships.map((m) => (
                <option key={m.tenantId} value={m.tenantId}>
                  {m.tenantName ?? m.tenantSlug}
                </option>
              ))}
            </Select>
          </div>
        ) : (
          <p className="mb-4 text-sm font-semibold">{active.tenantName}</p>
        )}
        {nav}
        <div className="mt-6 border-t border-border pt-4 text-xs text-muted">
          {email ? <p className="mb-2 truncate">{email}</p> : null}
          <p className="mb-2">
            {active.roles.map((r) => r.replace('_', ' ').toLowerCase()).join(', ')}
          </p>
          <Button variant="secondary" size="sm" onClick={() => void signOut()}>
            <LogOut className="h-3 w-3" /> Sign out
          </Button>
        </div>
      </aside>
      <div className="min-w-0">
        <header className="flex items-center gap-2 border-b border-border bg-card p-3 md:hidden">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <span className="font-bold text-primary">Workforce</span>
        </header>
        <main className="mx-auto max-w-6xl p-4 md:p-6">
          {!isStaff && items.length === 0 ? (
            <div className="mx-auto mt-16 max-w-md space-y-2 text-center">
              <h1 className="text-xl font-bold">Use the mobile app</h1>
              <p className="text-sm text-muted">
                This dashboard is for managers and administrators. You can check in and see your
                attendance in the Workforce mobile app.
              </p>
            </div>
          ) : blocked ? (
            <div className="mx-auto mt-16 max-w-md space-y-2 text-center">
              <h1 className="text-xl font-bold">You don’t have access to this page</h1>
              <p className="text-sm text-muted">Ask a company administrator if you need it.</p>
            </div>
          ) : (
            children
          )}
        </main>
      </div>
    </div>
  );
}

const Center = ({ children }: { children: ReactNode }) => (
  <div className="flex min-h-screen flex-col items-center justify-center gap-3 p-6 text-center">
    {children}
  </div>
);
