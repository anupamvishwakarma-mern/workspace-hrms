import type { HTMLAttributes, ReactNode, TdHTMLAttributes, ThHTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

export const Card = ({ className, ...p }: HTMLAttributes<HTMLDivElement>) => (
  <div className={cn('rounded-xl border border-border bg-card p-4 shadow-sm', className)} {...p} />
);
export const CardTitle = ({ className, ...p }: HTMLAttributes<HTMLHeadingElement>) => (
  <h2 className={cn('text-sm font-semibold text-muted', className)} {...p} />
);

type Tone = 'success' | 'warn' | 'danger' | 'info' | 'neutral';
const tones: Record<Tone, string> = {
  success: 'bg-success-bg text-success',
  warn: 'bg-warn-bg text-warn',
  danger: 'bg-danger-bg text-danger',
  info: 'bg-info-bg text-info',
  neutral: 'bg-accent text-muted',
};
export const Badge = ({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) => (
  <span
    className={cn(
      'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold',
      tones[tone],
    )}
  >
    {children}
  </span>
);

export const statusTone = (s?: string): Tone =>
  (
    ({
      PRESENT: 'success',
      APPROVED: 'success',
      ACTIVE: 'success',
      HALF_DAY: 'warn',
      PENDING: 'warn',
      INCOMPLETE: 'warn',
      NOTICE_PERIOD: 'warn',
      ABSENT: 'danger',
      REJECTED: 'danger',
      TERMINATED: 'danger',
      INACTIVE: 'neutral',
    }) as Record<string, Tone>
  )[s ?? ''] ?? 'neutral';

export function Alert({
  tone = 'info',
  children,
}: {
  tone?: Exclude<Tone, 'neutral'>;
  children: ReactNode;
}) {
  return (
    <div
      role={tone === 'danger' ? 'alert' : 'status'}
      className={cn('rounded-lg border px-3 py-2 text-sm', tones[tone], 'border-current/20')}
    >
      {children}
    </div>
  );
}

export const Table = ({ className, ...p }: HTMLAttributes<HTMLTableElement>) => (
  <div className="overflow-x-auto rounded-xl border border-border bg-card">
    <table className={cn('w-full text-left text-sm', className)} {...p} />
  </div>
);
export const Th = ({ className, ...p }: ThHTMLAttributes<HTMLTableCellElement>) => (
  <th
    scope="col"
    className={cn(
      'whitespace-nowrap border-b border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide text-muted',
      className,
    )}
    {...p}
  />
);
export const Td = ({ className, ...p }: TdHTMLAttributes<HTMLTableCellElement>) => (
  <td
    className={cn('border-b border-border px-3 py-2 align-middle last:border-b-0', className)}
    {...p}
  />
);

export const Skeleton = ({ className }: { className?: string }) => (
  <div aria-hidden className={cn('animate-pulse rounded-md bg-accent', className)} />
);

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold">{title}</h1>
        {description ? <p className="text-sm text-muted">{description}</p> : null}
      </div>
      <div className="flex flex-wrap gap-2">{actions}</div>
    </div>
  );
}

export const Empty = ({ children }: { children: ReactNode }) => (
  <p className="px-3 py-8 text-center text-sm text-muted">{children}</p>
);
