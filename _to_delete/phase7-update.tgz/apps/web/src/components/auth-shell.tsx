import type { ReactNode } from 'react';
import { Card } from '@/components/ui/display';

export function AuthShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-sm space-y-4 p-6">
        <div>
          <p className="text-sm font-semibold text-primary">Workforce</p>
          <h1 className="text-2xl font-bold">{title}</h1>
        </div>
        {children}
      </Card>
    </main>
  );
}
