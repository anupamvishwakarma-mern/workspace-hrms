import { describe, expect, it } from 'vitest';
import { EnvValidationError, integrationStatus, parseEnv } from '../src/config/env';

const base = {
  MONGODB_URI: 'mongodb://localhost/x',
  JWT_ACCESS_SECRET: 'a'.repeat(32),
  REFRESH_TOKEN_SECRET: 'b'.repeat(32),
};

describe('env validation', () => {
  it('rejects missing required variables', () => {
    expect(() => parseEnv({})).toThrow(EnvValidationError);
  });
  it('rejects short secrets', () => {
    expect(() => parseEnv({ ...base, JWT_ACCESS_SECRET: 'short' })).toThrow(/at least 32/);
  });
  it('applies defaults and parses CORS origins', () => {
    const env = parseEnv({ ...base, CORS_ORIGINS: 'http://a.test, http://b.test' });
    expect(env.API_PORT).toBe(4000);
    expect(env.CORS_ORIGINS).toEqual(['http://a.test', 'http://b.test']);
  });
  it('rejects placeholder secrets and wildcard CORS in production', () => {
    expect(() =>
      parseEnv({ ...base, NODE_ENV: 'production', JWT_ACCESS_SECRET: 'change-me'.padEnd(40, 'x') }),
    ).toThrow(/placeholder/);
    expect(() => parseEnv({ ...base, NODE_ENV: 'production', CORS_ORIGINS: '*' })).toThrow(
      /Wildcard/,
    );
  });
  it('requires SMTP settings when email provider is smtp', () => {
    expect(() => parseEnv({ ...base, EMAIL_PROVIDER: 'smtp' })).toThrow(/SMTP_HOST/);
  });
  it('reports integrations as not configured by default, without secrets', () => {
    const status = integrationStatus(parseEnv(base));
    expect(Object.values(status).every((v) => v === 'not_configured')).toBe(true);
  });
});
