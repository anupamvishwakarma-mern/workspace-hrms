# Mobile app (apps/mobile)

Expo SDK 58 · React Native 0.88 · Expo Router · TanStack Query · React Hook Form + Zod · TypeScript (strict).
Employee-facing: sign in, check in/out, breaks, today's summary, history, correction requests, GPS-exception requests.
Managers/HR review requests through the API (dashboard arrives in Phase 5); the app only shows the signed-in person's own data.

## Run it

```powershell
pnpm install
docker compose up -d mongo
pnpm --filter @workforce/api seed
pnpm dev:api
copy apps\mobile\.env.example apps\mobile\.env
pnpm dev:mobile
```

`EXPO_PUBLIC_API_URL` must include `/api/v1`:

| Where the app runs      | URL                                                                    |
| ----------------------- | ---------------------------------------------------------------------- |
| Android emulator        | `http://10.0.2.2:4000/api/v1`                                          |
| Phone on the same Wi-Fi | `http://<PC LAN IP>:4000/api/v1` (allow port 4000 in Windows Firewall) |
| iOS simulator           | `http://localhost:4000/api/v1`                                         |
| Release builds          | `https://...` only. The app refuses plain `http` outside development.  |

Sign in with `asha@demo.test` / `Demo-Pass-12345` (local seed only).
Expo Go may not support the newest SDK on your phone; if it does not, create a development build (`npx expo run:android`).

### Testing check-in locally

The seeded geofence is Bengaluru HQ (12.9716, 77.5946, 150 m radius), so a phone elsewhere will be "outside". Either set the emulator location (Android Studio: Extended controls, Location) to those coordinates, or sign in as `hr@demo.test` in the API (`PATCH /work-locations/:id`) and move the fence to where you are. Testing the outside case is useful too: the app then offers a "send for approval" request with a reason.

## Architecture

- `src/lib/api.ts`: fetch client. Access token is kept **in memory only**; the rotating refresh token is stored with `expo-secure-store` (Keychain/Keystore, this-device-only). On a 401 it refreshes **once, shared by all concurrent requests** (otherwise the server's refresh-token reuse detection would revoke the session), persists the new refresh token before using the new access token, and retries the request once. A network failure while refreshing keeps the user signed in; only a definitive rejection signs them out.
- `X-Tenant-Id` is sent only as a _selector_; the server re-checks membership every request. The company choice is stored, and the query cache is cleared on sign-out and company switch so one company's data never shows in another.
- Every response is parsed with a Zod schema (`src/lib/schemas.ts`); unexpected shapes are rejected.
- `src/lib/punchFlow.ts`: one location reading (foreground, only when a button is tapped) + an idempotency key + the call. After a timeout or network error the **same key** is reused for a retry of the same action within 10 minutes, so a retry cannot double-record (the server returns the original event). Definitive answers clear it.
- The device never decides attendance: the server assigns the time, verifies the geofence and state, and returns the new state. The phone's clock is sent as diagnostics only.
- Times are displayed in the **company/shift timezone** returned by `GET /attendance/me/today`, not the phone's.

## Design system

The app shares the web app's visual language: teal brand (`#0f766e`, `#2dd4bf` in dark mode), slate neutrals, rounded cards with soft shadows, dot-style status badges, avatar initials, and a segmented control. Tokens live in `src/theme.ts` (light/dark follow the OS), reusable pieces in `src/components/ui.tsx`, and tab icons in `src/components/icons.tsx` (drawn with plain Views, so no icon font or SVG dependency). Behaviour, accessibility labels/hints and all `src/lib` logic are unchanged by the redesign.

The Today screen leads with a status card (live session time, large Check in / Check out button), followed by Worked/Breaks tiles, a summary and the day's punches.

## Location and privacy

Location is read once per tap (high accuracy, 20 s timeout), never in the background (no background permission is requested on either platform). Coordinates are sent to the API and not logged or stored on the device. Android's "mock location" flag is sent as a risk signal for reviewers; it does not block the punch on the device. A geofence match shows the device _reported_ a position inside the fence. It does not prove the person was there. `deviceId` (Android ID / iOS vendor ID) is sent so reviewers can spot one device used by several people; remove it in `punchFlow.ts` if your policy forbids it.

## Tests

```powershell
pnpm --filter @workforce/mobile test      # client, refresh, idempotency, forms, formatting
pnpm --filter @workforce/api test         # includes tests/mobile-contract.test.ts
```

`mobile-contract.test.ts` runs the real mobile `ApiClient` and schemas against the real API over HTTP (login, token rotation and replay rejection, punches, 202 exceptions, idempotent replay, corrections). `npx expo export` was used to confirm that Android and iOS bundles build.

## Limitations

- **Never run on a device or emulator in the build environment.** Screens are type-checked and bundled, but layout, permission prompts, GPS behaviour, keyboard handling and navigation guards have not been exercised. Expect to fix visual and platform issues on first run.
- No screen/component tests.
- No offline punch queue, by design: the server clock is authoritative, so a punch made offline and sent later would carry the wrong time. The app asks the user to retry when online.
- A response lost after the server rotates a refresh token can make the next refresh look like token reuse and end the session (user signs in again).
- No push notifications (Phase 6), biometric app lock, localization, or app icons/splash (placeholders needed before store release). Bundle ids are `com.example.workforce`; change them before building.
- Request status is shown on refresh; there is no live push when a reviewer decides.
- The person's email is shown only after an interactive sign-in (`/auth/me` does not return it).

## API note (Phase 5)

Memberships returned by login and `/auth/me` now also include a sorted `permissions` array (used by the web menu). The mobile app ignores it; the API still enforces every permission.

## API note (Phase 6)

The API now has push-token endpoints (`POST /me/push-tokens`, `/me/push-tokens/remove`), leave endpoints and employee documents. **The mobile app does not use them yet**: it needs `expo-notifications` and a real device build to register tokens, and has no leave or document screens.
