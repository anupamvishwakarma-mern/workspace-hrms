import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, Linking, Text, View } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import {
  Badge,
  Banner,
  Body,
  Button,
  Card,
  Eyebrow,
  Field,
  Loading,
  PageHeader,
  Screen,
  Stat,
  toneForStatus,
} from '@/components/ui';
import { useToday } from '@/hooks/queries';
import { api } from '@/lib/client';
import { ApiError, isGeoFailure, userMessage, type GeoErrorDetails } from '@/lib/errors';
import { EVENT_LABEL, STATE_LABEL, STATUS_LABEL, formatMinutes, formatTime } from '@/lib/format';
import { LOCATION_MESSAGES, LocationError } from '@/lib/location';
import { performPunch, type PunchResult } from '@/lib/punchFlow';
import type { AllowedAction, EventType } from '@/lib/schemas';
import { useTheme } from '@/theme';

const BUTTON_LABEL: Record<EventType, string> = {
  CHECK_IN: 'Check in',
  CHECK_OUT: 'Check out',
  BREAK_START: 'Start break',
  BREAK_END: 'End break',
};

interface GeoPrompt {
  action: EventType;
  message: string;
  allowRequest: boolean;
}

export default function Today() {
  const t = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const { active } = useAuth();
  const today = useToday();
  const [notice, setNotice] = useState<{ tone: 'success' | 'info'; text: string }>();
  const [error, setError] = useState<{ text: string; openSettings?: boolean }>();
  const [geo, setGeo] = useState<GeoPrompt>();
  const [reason, setReason] = useState('');
  const [reasonError, setReasonError] = useState<string>();

  const punch = useMutation({
    mutationFn: (v: { action: EventType; reason?: string }) =>
      performPunch(api, v.action, v.reason),
    onMutate: () => {
      setError(undefined);
      setNotice(undefined);
    },
    onSuccess: (res: PunchResult) => {
      setGeo(undefined);
      setReason('');
      setNotice(
        res.kind === 'PENDING_REVIEW'
          ? {
              tone: 'info',
              text: `${EVENT_LABEL[res.eventType]} request sent for approval. It is not recorded until a reviewer approves it.`,
            }
          : {
              tone: 'success',
              text: res.replayed
                ? `${EVENT_LABEL[res.eventType]} was already recorded.`
                : `${EVENT_LABEL[res.eventType]}.`,
            },
      );
      void qc.invalidateQueries({ queryKey: ['today'] });
      void qc.invalidateQueries({ queryKey: ['history'] });
      void qc.invalidateQueries({ queryKey: ['exceptions'] });
    },
    onError: (e, v) => {
      if (isGeoFailure(e)) {
        const d = (e.details ?? {}) as GeoErrorDetails;
        const extra =
          e.code === 'OUTSIDE_GEOFENCE' && d.distanceMeters
            ? ` (about ${Math.round(d.distanceMeters)} m away)`
            : '';
        setGeo({
          action: v.action,
          message: `${userMessage(e)}${extra}`,
          allowRequest: !!d.exceptionAllowed,
        });
        return;
      }
      setGeo(undefined);
      if (e instanceof LocationError)
        setError({
          text: LOCATION_MESSAGES[e.kind],
          openSettings: e.kind === 'PERMISSION_DENIED' && !e.canAskAgain,
        });
      else {
        setError({ text: userMessage(e) });
        // The state may have changed on the server (e.g. punched from another device): refresh it.
        if (e instanceof ApiError && e.code === 'INVALID_TRANSITION')
          void qc.invalidateQueries({ queryKey: ['today'] });
      }
    },
  });

  const confirmAndPunch = (a: AllowedAction) => {
    const go = () => punch.mutate({ action: a.eventType });
    if (a.eventType === 'CHECK_OUT')
      Alert.alert('Check out?', 'This ends your work session for today.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Check out', onPress: go },
      ]);
    else go();
  };

  const submitException = () => {
    if (!geo) return;
    const r = reason.trim();
    if (r.length < 5)
      return setReasonError('Explain why you need approval (at least 5 characters).');
    setReasonError(undefined);
    punch.mutate({ action: geo.action, reason: r });
  };

  if (today.isPending) return <Loading />;
  if (today.isError)
    return (
      <Screen onRefresh={() => void today.refetch()} refreshing={today.isRefetching}>
        <PageHeader title="Today" />
        <Banner
          tone="danger"
          action={<Button title="Retry" variant="secondary" onPress={() => void today.refetch()} />}
        >
          {userMessage(today.error)}
        </Banner>
      </Screen>
    );

  const d = today.data;
  const tz = d.timezone;
  const missingEmployee = !active?.employeeId;
  const sum = d.summary;

  return (
    <Screen onRefresh={() => void today.refetch()} refreshing={today.isRefetching}>
      <PageHeader
        title="Today"
        subtitle={`${active?.tenantName ?? ''}${
          d.shift
            ? ` · ${d.shift.name} ${d.shift.startTime}–${d.shift.endTime}`
            : ' · No shift assigned'
        }`}
      />

      {missingEmployee ? (
        <Banner tone="warn">
          Your account has no employee profile in this company, so you cannot record attendance.
          Contact HR.
        </Banner>
      ) : null}
      {d.previousSessionIncomplete ? (
        <Banner
          tone="warn"
          action={
            <Button
              title="Request correction"
              variant="secondary"
              onPress={() =>
                router.push({
                  pathname: '/correction/new',
                  params: { workDate: d.previousSessionIncomplete?.workDate ?? '' },
                })
              }
            />
          }
        >
          A previous session
          {d.previousSessionIncomplete.workDate
            ? ` (${d.previousSessionIncomplete.workDate})`
            : ''}{' '}
          was never checked out. Ask for a correction so it is counted properly.
        </Banner>
      ) : null}
      {notice ? <Banner tone={notice.tone}>{notice.text}</Banner> : null}
      {error ? (
        <Banner
          tone="danger"
          action={
            error.openSettings ? (
              <Button
                title="Open Settings"
                variant="secondary"
                onPress={() => void Linking.openSettings()}
              />
            ) : undefined
          }
        >
          {error.text}
        </Banner>
      ) : null}

      <Card tone={d.state === 'WORKING' ? 'accent' : undefined}>
        <Badge
          label={STATE_LABEL[d.state]}
          tone={d.state === 'WORKING' ? 'success' : d.state === 'ON_BREAK' ? 'warn' : 'neutral'}
        />
        {d.openSince ? (
          <View style={{ gap: 2 }}>
            <Text style={{ color: t.text, fontSize: 40, fontWeight: '800', letterSpacing: -1 }}>
              {formatMinutes(d.currentSessionMinutes)}
            </Text>
            <Body muted>Since {formatTime(d.openSince, tz)}</Body>
          </View>
        ) : (
          <View style={{ gap: 2 }}>
            <Text style={{ color: t.text, fontSize: 28, fontWeight: '800', letterSpacing: -0.5 }}>
              Ready when you are
            </Text>
            <Body muted>You are not checked in.</Body>
          </View>
        )}
        {d.shift?.remainingMinutes !== undefined ? (
          <Body muted small>
            {formatMinutes(d.shift.remainingMinutes)} left in your shift
          </Body>
        ) : null}
        <View style={{ gap: 10, marginTop: 8 }}>
          {d.allowedActions
            .filter((a) => a.enabled)
            .map((a) => (
              <Button
                key={a.eventType}
                size={a.eventType === 'CHECK_IN' || a.eventType === 'CHECK_OUT' ? 'lg' : 'md'}
                title={BUTTON_LABEL[a.eventType]}
                variant={
                  a.eventType === 'CHECK_OUT'
                    ? 'danger'
                    : a.eventType === 'CHECK_IN'
                      ? 'primary'
                      : 'secondary'
                }
                disabled={missingEmployee || punch.isPending || !!geo}
                loading={punch.isPending && punch.variables?.action === a.eventType}
                onPress={() => confirmAndPunch(a)}
                accessibilityHint="Reads your location once to verify you are at your work location"
              />
            ))}
        </View>
        <Body muted small>
          Your location is read once when you tap a button, never in the background. The server
          records the time.
        </Body>
      </Card>

      {geo ? (
        <Card>
          <Banner tone="warn">{geo.message}</Banner>
          {geo.allowRequest ? (
            <>
              <Body>
                If you are working from an approved place that GPS cannot confirm, you can ask a
                reviewer to approve this {BUTTON_LABEL[geo.action].toLowerCase()}.
              </Body>
              <ReasonInput value={reason} onChange={setReason} error={reasonError} />
              <Button
                title="Send for approval"
                onPress={submitException}
                loading={punch.isPending}
              />
            </>
          ) : (
            <Body muted>
              Your company does not allow approval requests for location problems. Move to your work
              location and try again.
            </Body>
          )}
          <Button
            title="Cancel"
            variant="secondary"
            onPress={() => setGeo(undefined)}
            disabled={punch.isPending}
          />
        </Card>
      ) : null}

      <Eyebrow>Today so far</Eyebrow>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Stat label="Worked" value={formatMinutes(sum.workedMinutes)} />
        <Stat label="Breaks" value={formatMinutes(sum.breakMinutes)} />
      </View>
      <Card>
        <Row label="Status" value={sum.status ? (STATUS_LABEL[sum.status] ?? sum.status) : '—'} />
        <Row label="First in" value={formatTime(sum.firstCheckIn, tz)} />
        <Row label="Last out" value={formatTime(sum.lastCheckOut, tz)} />
        {sum.lateMinutes ? <Row label="Late by" value={formatMinutes(sum.lateMinutes)} /> : null}
        {d.correctionStatus === 'PENDING' ? (
          <Badge label="Correction pending" tone={toneForStatus('PENDING')} />
        ) : null}
      </Card>

      <Eyebrow>Punches</Eyebrow>
      <Card>
        {d.events.length === 0 ? (
          <Body muted>No punches yet.</Body>
        ) : (
          d.events.map((e) => (
            <Row key={e.id} label={EVENT_LABEL[e.eventType]} value={formatTime(e.occurredAt, tz)} />
          ))
        )}
      </Card>
    </Screen>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <Text style={{ color: t.muted }}>{label}</Text>
      <Text style={{ color: t.text, fontWeight: '600' }}>{value}</Text>
    </View>
  );
}
function ReasonInput({
  value,
  onChange,
  error,
}: {
  value: string;
  onChange: (v: string) => void;
  error?: string;
}) {
  return (
    <Field
      label="Reason"
      value={value}
      onChangeText={onChange}
      error={error}
      multiline
      maxLength={500}
      placeholder="e.g. Client site visit, office GPS unavailable"
    />
  );
}
