import { z } from 'zod';

/** Response schemas. Unknown extra fields are tolerated so older apps survive additive API changes. */
export const membership = z.object({
  tenantId: z.string(),
  tenantName: z.string().optional(),
  tenantSlug: z.string().optional(),
  tenantStatus: z.string().optional(),
  roles: z.array(z.string()),
  employeeId: z.string().optional(),
});
export type Membership = z.infer<typeof membership>;

export const loginData = z.object({
  accessToken: z.string(),
  refreshToken: z.string(),
  expiresIn: z.number(),
  user: z.object({ id: z.string(), email: z.string() }),
  memberships: z.array(membership),
});
export const refreshData = z.object({
  accessToken: z.string(),
  refreshToken: z.string(),
  expiresIn: z.number(),
});
export const meData = z.object({ userId: z.string(), memberships: z.array(membership) });

export const attendanceState = z.enum(['OFF', 'WORKING', 'ON_BREAK']);
export type AttendanceState = z.infer<typeof attendanceState>;
export const eventType = z.enum(['CHECK_IN', 'CHECK_OUT', 'BREAK_START', 'BREAK_END']);
export type EventType = z.infer<typeof eventType>;

export const allowedAction = z.object({
  action: z.string(),
  eventType,
  enabled: z.boolean(),
  reason: z.string().optional(),
});
export type AllowedAction = z.infer<typeof allowedAction>;

export const punchEvent = z.object({
  id: z.string(),
  eventType,
  occurredAt: z.string(),
  workDate: z.string(),
  source: z.string().optional(),
  verification: z.object({ status: z.string(), distanceMeters: z.number() }).partial().optional(),
  hasPhoto: z.boolean().default(false),
  workLocationName: z.string().optional(),
  location: z
    .object({
      latitude: z.number(),
      longitude: z.number(),
      accuracyMeters: z.number().optional(),
    })
    .optional(),
});
export type PunchEvent = z.infer<typeof punchEvent>;

const summary = z.object({
  status: z.string().nullable().optional(),
  firstCheckIn: z.string().nullable().optional(),
  lastCheckOut: z.string().nullable().optional(),
  workedMinutes: z.number().default(0),
  breakMinutes: z.number().default(0),
  lateMinutes: z.number().default(0),
  earlyDepartureMinutes: z.number().default(0),
  overtimeMinutes: z.number().default(0),
  scheduledMinutes: z.number().default(0),
  isOpen: z.boolean().optional(),
});

export const todayData = z.object({
  workDate: z.string(),
  timezone: z.string(),
  state: attendanceState,
  openSince: z.string().optional(),
  previousSessionIncomplete: z
    .object({ workDate: z.string().optional(), since: z.string().optional() })
    .optional(),
  currentSessionMinutes: z.number().optional(),
  allowedActions: z.array(allowedAction),
  shift: z
    .object({
      name: z.string(),
      startTime: z.string(),
      endTime: z.string(),
      timezone: z.string(),
      overnight: z.boolean().optional(),
      remainingMinutes: z.number().optional(),
    })
    .optional(),
  correctionStatus: z.string().nullable().optional(),
  summary,
  photoRequired: z.boolean().default(false),
  events: z.array(punchEvent),
  serverTime: z.string(),
});
export type TodayData = z.infer<typeof todayData>;

export const punchRecorded = z.object({
  replayed: z.boolean(),
  event: punchEvent,
  state: attendanceState,
  allowedActions: z.array(allowedAction),
});
export const punchPending = z.object({
  status: z.literal('PENDING_REVIEW'),
  replayed: z.boolean(),
  exception: z.object({ id: z.string(), eventType, status: z.string() }),
});

export const dayRecord = z.object({
  id: z.string(),
  workDate: z.string(),
  status: z.string().nullable().optional(),
  firstCheckIn: z.string().nullable().optional(),
  lastCheckOut: z.string().nullable().optional(),
  workedMinutes: z.number().default(0),
  breakMinutes: z.number().default(0),
  lateMinutes: z.number().default(0),
  earlyDepartureMinutes: z.number().default(0),
  overtimeMinutes: z.number().default(0),
  isOpen: z.boolean().optional(),
  correctionStatus: z.string().nullable().optional(),
});
export type DayRecord = z.infer<typeof dayRecord>;

export const correctionRecord = z.object({
  id: z.string(),
  workDate: z.string(),
  requestedChanges: z
    .object({ checkIn: z.string().nullish(), checkOut: z.string().nullish() })
    .partial()
    .optional(),
  reason: z.string(),
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED']),
  reviewComment: z.string().nullish(),
  createdAt: z.string().optional(),
});
export type CorrectionRecord = z.infer<typeof correctionRecord>;

export const exceptionRecord = z.object({
  id: z.string(),
  eventType,
  occurredAt: z.string(),
  failure: z.string().optional(),
  employeeReason: z.string().optional(),
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED']),
  reviewComment: z.string().nullish(),
});
export type ExceptionRecord = z.infer<typeof exceptionRecord>;

export const pageMeta = z.object({ page: z.number(), limit: z.number(), total: z.number() });

export const photoUpload = z.object({
  photoId: z.string(),
  upload: z.object({
    url: z.string().url(),
    headers: z.record(z.string(), z.string()),
  }),
});
export const photoView = z.object({ url: z.string().url() });
