import { focusManager, useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { AppState } from 'react-native';
import { z } from 'zod';
import { useAuth } from '@/auth/AuthProvider';
import { api } from '@/lib/client';
import { correctionRecord, dayRecord, exceptionRecord, pageMeta, todayData } from '@/lib/schemas';

/** Refetch when the app returns to the foreground (React Native has no window focus event). */
export function useAppStateFocus() {
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => focusManager.setFocused(s === 'active'));
    return () => sub.remove();
  }, []);
}

/** Cache keys include the company so switching companies can never show another company's data. */
const useTenantKey = () => useAuth().active?.tenantId ?? 'none';

export function useToday() {
  const tenant = useTenantKey();
  return useQuery({
    queryKey: ['today', tenant],
    queryFn: async () => (await api.call({ path: '/attendance/me/today', schema: todayData })).data,
    refetchInterval: 60_000,
    staleTime: 15_000,
  });
}

const PAGE = 20;
export function useHistory() {
  const tenant = useTenantKey();
  return useInfiniteQuery({
    queryKey: ['history', tenant],
    initialPageParam: 1,
    queryFn: async ({ pageParam }) => {
      const r = await api.call({
        path: '/attendance/me/history',
        query: { page: pageParam, limit: PAGE },
        schema: z.array(dayRecord),
      });
      return { items: r.data, meta: pageMeta.parse(r.meta) };
    },
    getNextPageParam: (last) =>
      last.meta.page * last.meta.limit < last.meta.total ? last.meta.page + 1 : undefined,
  });
}

export function useMyCorrections() {
  const { active } = useAuth();
  return useQuery({
    queryKey: ['corrections', active?.tenantId ?? 'none'],
    enabled: !!active?.employeeId,
    queryFn: async () =>
      (
        await api.call({
          path: '/attendance/corrections',
          // Managers/HR can list more than their own; the app only shows the person's own requests.
          query: { employeeId: active!.employeeId, limit: 50 },
          schema: z.array(correctionRecord),
        })
      ).data,
  });
}

export function useMyExceptions() {
  const tenant = useTenantKey();
  return useQuery({
    queryKey: ['exceptions', tenant],
    queryFn: async () =>
      (
        await api.call({
          path: '/attendance/me/exceptions',
          query: { limit: 50 },
          schema: z.array(exceptionRecord),
        })
      ).data,
  });
}
