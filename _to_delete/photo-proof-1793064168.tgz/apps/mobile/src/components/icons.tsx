import { Text, View, type ColorValue } from 'react-native';

export type IconName = 'clock' | 'calendar' | 'inbox' | 'user' | 'check' | 'info' | 'alert';

/** Tiny dependency-free icons drawn with Views, so no icon font or SVG package is needed. */
export function Icon({
  name,
  color,
  size = 22,
}: {
  name: IconName;
  color: ColorValue;
  size?: number;
}) {
  const w = Math.max(1.75, size / 11);
  const box = {
    width: size,
    height: size,
    alignItems: 'center',
    justifyContent: 'center',
  } as const;
  switch (name) {
    case 'clock':
      return (
        <View style={box} accessibilityElementsHidden importantForAccessibility="no">
          <View
            style={{
              width: size,
              height: size,
              borderRadius: size,
              borderWidth: w,
              borderColor: color,
            }}
          />
          <View
            style={{
              position: 'absolute',
              width: w,
              height: size * 0.3,
              backgroundColor: color,
              top: size * 0.2,
              borderRadius: w,
            }}
          />
          <View
            style={{
              position: 'absolute',
              width: size * 0.22,
              height: w,
              backgroundColor: color,
              left: size * 0.5,
              top: size * 0.5 - w / 2,
              borderRadius: w,
            }}
          />
        </View>
      );
    case 'calendar':
      return (
        <View style={box} accessibilityElementsHidden importantForAccessibility="no">
          <View
            style={{
              width: size,
              height: size * 0.88,
              borderRadius: size * 0.2,
              borderWidth: w,
              borderColor: color,
              marginTop: size * 0.08,
            }}
          />
          <View
            style={{
              position: 'absolute',
              top: size * 0.34,
              width: size,
              height: w,
              backgroundColor: color,
            }}
          />
          <View
            style={{
              position: 'absolute',
              top: 0,
              left: size * 0.26,
              width: w,
              height: size * 0.2,
              backgroundColor: color,
              borderRadius: w,
            }}
          />
          <View
            style={{
              position: 'absolute',
              top: 0,
              right: size * 0.26,
              width: w,
              height: size * 0.2,
              backgroundColor: color,
              borderRadius: w,
            }}
          />
        </View>
      );
    case 'inbox':
      return (
        <View style={box} accessibilityElementsHidden importantForAccessibility="no">
          <View
            style={{
              width: size,
              height: size * 0.82,
              borderRadius: size * 0.2,
              borderWidth: w,
              borderColor: color,
            }}
          />
          <View
            style={{
              position: 'absolute',
              top: size * 0.3,
              width: size * 0.5,
              height: w,
              backgroundColor: color,
              borderRadius: w,
            }}
          />
          <View
            style={{
              position: 'absolute',
              top: size * 0.5,
              width: size * 0.34,
              height: w,
              backgroundColor: color,
              borderRadius: w,
            }}
          />
        </View>
      );
    case 'user':
      return (
        <View style={box} accessibilityElementsHidden importantForAccessibility="no">
          <View
            style={{
              width: size * 0.42,
              height: size * 0.42,
              borderRadius: size,
              borderWidth: w,
              borderColor: color,
            }}
          />
          <View
            style={{
              width: size * 0.8,
              height: size * 0.4,
              marginTop: size * 0.08,
              borderTopLeftRadius: size,
              borderTopRightRadius: size,
              borderWidth: w,
              borderBottomWidth: 0,
              borderColor: color,
            }}
          />
        </View>
      );
    default: {
      const glyph = name === 'check' ? '✓' : name === 'alert' ? '!' : 'i';
      return (
        <View
          accessibilityElementsHidden
          importantForAccessibility="no"
          style={{
            ...box,
            borderRadius: size,
            borderWidth: w,
            borderColor: color,
          }}
        >
          <Glyph color={color} size={size * 0.62} text={glyph} />
        </View>
      );
    }
  }
}

function Glyph({ color, size, text }: { color: ColorValue; size: number; text: string }) {
  return (
    <Text style={{ color, fontSize: size, fontWeight: '800', lineHeight: size * 1.15 }}>
      {text}
    </Text>
  );
}
