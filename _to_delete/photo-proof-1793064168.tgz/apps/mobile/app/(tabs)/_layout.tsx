import { Tabs } from 'expo-router';
import { Icon, type IconName } from '@/components/icons';
import { useTheme } from '@/theme';

const TAB_ICON: Record<string, IconName> = {
  index: 'clock',
  history: 'calendar',
  requests: 'inbox',
  profile: 'user',
};

export default function TabsLayout() {
  const t = useTheme();
  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: t.primary,
        tabBarInactiveTintColor: t.muted,
        tabBarLabelStyle: { fontSize: 12, fontWeight: '700' },
        tabBarStyle: {
          backgroundColor: t.card,
          borderTopColor: t.border,
          paddingTop: 6,
          height: 64,
        },
        tabBarIcon: ({ color }) => (
          <Icon name={TAB_ICON[route.name] ?? 'info'} color={color} size={22} />
        ),
      })}
    >
      <Tabs.Screen name="index" options={{ title: 'Today' }} />
      <Tabs.Screen name="history" options={{ title: 'History' }} />
      <Tabs.Screen name="requests" options={{ title: 'Requests' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
    </Tabs>
  );
}
