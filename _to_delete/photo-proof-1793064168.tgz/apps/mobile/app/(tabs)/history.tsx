import { useRouter } from 'expo-router';
import { FlatList, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Badge,
  Banner,
  Body,
  Button,
  Card,
  EmptyState,
  Loading,
  PageHeader,
  toneForStatus,
} from '@/components/ui';
import { useHistory, useToday } from '@/hooks/queries';
import { userMessage } from '@/lib/errors';
import { STATUS_LABEL, formatMinutes, formatTime, formatWorkDate } from '@/lib/format';
import { useTheme } from '@/theme';

export default function History() {
  const t = useTheme();
  const router = useRouter();
  const q = useHistory();
  const tz = useToday().data?.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
  const items = q.data?.pages.flatMap((p) => p.items) ?? [];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top', 'left', 'right']}>
      <FlatList
        data={items}
        keyExtractor={(d) => d.id}
        contentContainerStyle={{ padding: 20, gap: 14 }}
        refreshing={q.isRefetching && !q.isFetchingNextPage}
        onRefresh={() => void q.refetch()}
        onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && void q.fetchNextPage()}
        onEndReachedThreshold={0.4}
        ListHeaderComponent={
          <PageHeader title="History" subtitle="Your recent attendance, newest first." />
        }
        ListEmptyComponent={
          q.isPending ? (
            <Loading />
          ) : q.isError ? (
            <Banner
              tone="danger"
              action={<Button title="Retry" variant="secondary" onPress={() => void q.refetch()} />}
            >
              {userMessage(q.error)}
            </Banner>
          ) : (
            <EmptyState
              title="No attendance yet"
              hint="Days appear here after your first check-in."
            />
          )
        }
        ListFooterComponent={q.isFetchingNextPage ? <Loading /> : undefined}
        renderItem={({ item: d }) => (
          <Card>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Text style={{ color: t.text, fontSize: 17, fontWeight: '700' }}>
                {formatWorkDate(d.workDate)}
              </Text>
              <Badge
                label={d.status ? (STATUS_LABEL[d.status] ?? d.status) : 'In progress'}
                tone={toneForStatus(d.status)}
              />
            </View>
            <Body muted small>
              {formatTime(d.firstCheckIn, tz)} –{' '}
              {d.isOpen ? 'working' : formatTime(d.lastCheckOut, tz)} ·{' '}
              {formatMinutes(d.workedMinutes)} worked
            </Body>
            {d.lateMinutes ? (
              <Body muted small>
                Late by {formatMinutes(d.lateMinutes)}
              </Body>
            ) : null}
            {d.correctionStatus === 'PENDING' ? (
              <Badge label="Correction pending" tone="warn" />
            ) : null}
            <Button
              title="Request correction"
              variant="ghost"
              onPress={() =>
                router.push({ pathname: '/correction/new', params: { workDate: d.workDate } })
              }
            />
          </Card>
        )}
      />
    </SafeAreaView>
  );
}
