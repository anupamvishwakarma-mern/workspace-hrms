import { Pressable } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { View } from 'react-native';
import { Avatar, Body, Button, Card, PageHeader, Screen } from '@/components/ui';

export default function Company() {
  const { memberships, selectCompany, signOut } = useAuth();
  return (
    <Screen>
      <PageHeader
        title="Choose a company"
        subtitle="Your account belongs to more than one company. You can switch later from Profile."
      />
      {memberships.map((m) => (
        <Pressable
          key={m.tenantId}
          onPress={() => void selectCompany(m.tenantId)}
          accessibilityRole="button"
          accessibilityLabel={`Open ${m.tenantName ?? 'company'}`}
        >
          <Card>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <Avatar name={m.tenantName ?? m.tenantSlug ?? m.tenantId} />
              <View style={{ flex: 1, gap: 2 }}>
                <Body bold>{m.tenantName ?? m.tenantSlug ?? m.tenantId}</Body>
                <Body muted small>
                  {m.roles.join(', ')}
                </Body>
              </View>
            </View>
          </Card>
        </Pressable>
      ))}
      <Button title="Sign out" variant="secondary" onPress={() => void signOut()} />
    </Screen>
  );
}
