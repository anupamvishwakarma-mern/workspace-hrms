import type { Router } from 'express';
import mongoose from 'mongoose';
import { z } from 'zod';
import type { Env } from '../../config/env';
import { Employee } from '../../database/models/employee.model';
import { Membership } from '../../database/models/membership.model';
import { Tenant } from '../../database/models/tenant.model';
import { User } from '../../database/models/user.model';
import { authenticate, requirePlatformAdmin } from '../../middleware/auth';
import { asyncHandler } from '../../utils/asyncHandler';
import { AppError } from '../../utils/errors';
import { isDuplicateKey } from '../../utils/mongo';
import { route } from '../../utils/route';
import { idParams, paginationQuery, validate } from '../../utils/validate';
import { writeAudit } from '../audit/audit.service';
import { issueOneTimeToken } from '../auth/token.service';
import { sendEmail } from '../notifications/email.service';
import { serializeTenant, timezoneSchema } from '../tenants/tenants.routes';

const createBody = z
  .object({
    name: z.string().trim().min(1).max(200),
    slug: z
      .string()
      .trim()
      .toLowerCase()
      .regex(
        /^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$/,
        'Slug must be 3-40 chars: lowercase letters, digits, hyphens',
      ),
    timezone: timezoneSchema.default('UTC'),
    owner: z
      .object({
        email: z
          .string()
          .email()
          .max(254)
          .transform((s) => s.toLowerCase()),
        firstName: z.string().trim().min(1).max(100),
        lastName: z.string().trim().min(1).max(100),
      })
      .strict(),
  })
  .strict();
const statusBody = z
  .object({
    status: z.enum(['ACTIVE', 'SUSPENDED', 'CLOSED']),
    reason: z.string().trim().min(3).max(500),
  })
  .strict();
const listQuery = z
  .object({ ...paginationQuery, status: z.enum(['ACTIVE', 'SUSPENDED', 'CLOSED']).optional() })
  .strict();

/**
 * Platform (SaaS operator) endpoints. By design they expose tenant metadata and counts only -
 * a platform admin has no tenant membership and therefore cannot read employee records.
 */
export function registerPlatformRoutes(v1: Router, env: Env): void {
  const chain = [authenticate(env), requirePlatformAdmin];

  route(
    v1,
    {
      method: 'post',
      path: '/platform/tenants',
      summary: 'Onboard a company and invite its first owner.',
      tags: ['Platform'],
      auth: 'platform',
      body: createBody,
      successStatus: 201,
    },
    ...chain,
    validate({ body: createBody }),
    asyncHandler(async (req, res) => {
      const { name, slug, timezone, owner } = req.body as z.infer<typeof createBody>;
      if (await User.exists({ email: owner.email, status: 'DISABLED' }))
        throw AppError.conflict('Owner account is disabled');
      const session = await mongoose.startSession();
      let tenantId!: mongoose.Types.ObjectId;
      let ownerUserId!: mongoose.Types.ObjectId;
      let ownerStatus!: string;
      try {
        await session.withTransaction(async () => {
          const [tenant] = await Tenant.create([{ name, slug, timezone }], { session });
          tenantId = tenant!._id;
          let user = await User.findOne({ email: owner.email }).session(session);
          user ??= (
            await User.create([{ email: owner.email, status: 'INVITED' }], { session })
          )[0]!;
          ownerUserId = user._id;
          ownerStatus = user.status;
          const [emp] = await Employee.create(
            [
              {
                tenantId,
                userId: user._id,
                employeeCode: 'EMP-0001',
                firstName: owner.firstName,
                lastName: owner.lastName,
                workEmail: owner.email,
                employmentStatus: user.status === 'ACTIVE' ? 'ACTIVE' : 'INVITED',
                history: [{ type: 'CREATED', byUserId: req.auth!.userId }],
              },
            ],
            { session },
          );
          await Membership.create(
            [{ tenantId, userId: user._id, roles: ['COMPANY_OWNER'], employeeId: emp!._id }],
            { session },
          );
        });
      } catch (err) {
        if (isDuplicateKey(err)) throw AppError.conflict('A company with this slug already exists');
        throw err;
      } finally {
        await session.endSession();
      }
      if (ownerStatus === 'INVITED') {
        const raw = await issueOneTimeToken(
          env,
          ownerUserId,
          'ACTIVATION',
          env.INVITE_TTL_HOURS * 3_600_000,
        );
        await sendEmail(env, {
          tenantId,
          to: owner.email,
          template: 'ACTIVATION',
          subject: `Your ${name} workspace is ready`,
          link: `${env.WEB_APP_URL}/activate?token=${raw}`,
        });
      }
      const tenant = await Tenant.findById(tenantId).lean();
      await writeAudit(req, {
        action: 'platform.tenant_create',
        entityType: 'Tenant',
        entityId: tenantId,
        tenantId,
        after: tenant,
      });
      res.status(201).json({ success: true, data: serializeTenant(tenant!) });
    }),
  );

  route(
    v1,
    {
      method: 'get',
      path: '/platform/tenants',
      summary: 'List companies (metadata only).',
      tags: ['Platform'],
      auth: 'platform',
      query: listQuery,
    },
    ...chain,
    validate({ query: listQuery }),
    asyncHandler(async (req, res) => {
      const q = req.query as unknown as z.infer<typeof listQuery>;
      const filter = q.status ? { status: q.status } : {};
      const [items, total] = await Promise.all([
        Tenant.find(filter)
          .sort({ createdAt: -1 })
          .skip((q.page - 1) * q.limit)
          .limit(q.limit)
          .lean(),
        Tenant.countDocuments(filter),
      ]);
      res.json({
        success: true,
        data: items.map(serializeTenant),
        meta: { page: q.page, limit: q.limit, total },
      });
    }),
  );

  route(
    v1,
    {
      method: 'patch',
      path: '/platform/tenants/:id/status',
      summary: 'Activate, suspend or close a company.',
      tags: ['Platform'],
      auth: 'platform',
      body: statusBody,
    },
    ...chain,
    validate({ params: idParams, body: statusBody }),
    asyncHandler(async (req, res) => {
      const before = await Tenant.findById(req.params.id).lean();
      if (!before) throw AppError.notFound('Company not found');
      const after = await Tenant.findByIdAndUpdate(
        before._id,
        { $set: { status: req.body.status } },
        { new: true },
      ).lean();
      await writeAudit(req, {
        action: 'platform.tenant_status',
        entityType: 'Tenant',
        entityId: before._id,
        tenantId: before._id,
        before: { status: before.status },
        after: { status: req.body.status },
        reason: req.body.reason,
      });
      res.json({ success: true, data: serializeTenant(after!) });
    }),
  );

  route(
    v1,
    {
      method: 'get',
      path: '/platform/metrics',
      summary: 'Platform-level operational counts (no tenant business data).',
      tags: ['Platform'],
      auth: 'platform',
    },
    ...chain,
    asyncHandler(async (_req, res) => {
      const [byStatus, users] = await Promise.all([
        Tenant.aggregate<{ _id: string; count: number }>([
          { $group: { _id: '$status', count: { $sum: 1 } } },
        ]),
        User.countDocuments({ status: 'ACTIVE' }),
      ]);
      res.json({
        success: true,
        data: {
          tenantsByStatus: Object.fromEntries(byStatus.map((b) => [b._id, b.count])),
          activeUsers: users,
        },
      });
    }),
  );
}
