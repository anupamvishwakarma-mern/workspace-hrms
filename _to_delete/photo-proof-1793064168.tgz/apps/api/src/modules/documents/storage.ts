import {
  DeleteObjectCommand,
  GetObjectCommand,
  HeadObjectCommand,
  PutObjectCommand,
  S3Client,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import type { Env } from '../../config/env';

export interface ObjectStorage {
  presignUpload(
    key: string,
    contentType: string,
    sizeBytes: number,
    ttlSeconds: number,
  ): Promise<string>;
  presignDownload(key: string, fileName: string, ttlSeconds: number): Promise<string>;
  head(key: string): Promise<{ sizeBytes: number; contentType?: string } | null>;
  remove(key: string): Promise<void>;
}

export class S3Storage implements ObjectStorage {
  private readonly client: S3Client;
  constructor(
    endpoint: string,
    region: string,
    accessKeyId: string,
    secretAccessKey: string,
    private readonly bucket: string,
  ) {
    this.client = new S3Client({
      endpoint,
      region,
      credentials: { accessKeyId, secretAccessKey },
      forcePathStyle: true, // works for MinIO/R2/S3 alike
    });
  }
  presignUpload(key: string, contentType: string, sizeBytes: number, ttl: number) {
    // Content-Type and Content-Length are part of the signature: the client cannot upload a different type or size.
    return getSignedUrl(
      this.client,
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        ContentType: contentType,
        ContentLength: sizeBytes,
      }),
      { expiresIn: ttl },
    );
  }
  presignDownload(key: string, fileName: string, ttl: number) {
    const safe = fileName.replace(/[^\w.\- ]/g, '_');
    return getSignedUrl(
      this.client,
      new GetObjectCommand({
        Bucket: this.bucket,
        Key: key,
        ResponseContentDisposition: `attachment; filename="${safe}"`,
      }),
      { expiresIn: ttl },
    );
  }
  async head(key: string) {
    try {
      const r = await this.client.send(new HeadObjectCommand({ Bucket: this.bucket, Key: key }));
      return { sizeBytes: r.ContentLength ?? 0, contentType: r.ContentType };
    } catch (e) {
      const status = (e as { $metadata?: { httpStatusCode?: number } }).$metadata?.httpStatusCode;
      if (status === 404 || (e as Error).name === 'NotFound') return null;
      throw e;
    }
  }
  async remove(key: string) {
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}

let cache: { sig: string; storage: ObjectStorage } | undefined;
/** Null when object storage is not configured: document endpoints then answer 503 instead of pretending. */
export function getStorage(env: Env): ObjectStorage | null {
  const {
    OBJECT_STORAGE_ENDPOINT: e,
    OBJECT_STORAGE_BUCKET: b,
    OBJECT_STORAGE_ACCESS_KEY: k,
    OBJECT_STORAGE_SECRET_KEY: s,
  } = env;
  if (!e || !b || !k || !s) return null;
  const sig = `${e}|${b}|${k}|${env.OBJECT_STORAGE_REGION}`;
  if (cache?.sig !== sig)
    cache = { sig, storage: new S3Storage(e, env.OBJECT_STORAGE_REGION, k, s, b) };
  return cache.storage;
}
