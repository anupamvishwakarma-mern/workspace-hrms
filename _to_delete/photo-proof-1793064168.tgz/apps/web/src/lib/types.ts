export interface Membership {
  tenantId: string;
  tenantName?: string;
  tenantSlug?: string;
  tenantStatus?: string;
  roles: string[];
  permissions: string[];
  employeeId?: string;
}
export type Role = 'COMPANY_OWNER' | 'HR_ADMIN' | 'MANAGER' | 'EMPLOYEE' | 'PAYROLL_ADMIN';
export const ROLES: Role[] = ['COMPANY_OWNER', 'HR_ADMIN', 'MANAGER', 'EMPLOYEE', 'PAYROLL_ADMIN'];

export interface Employee {
  id: string;
  employeeCode: string;
  firstName: string;
  lastName: string;
  workEmail?: string;
  phone?: string;
  departmentId?: string;
  managerId?: string;
  designation?: string;
  employmentStatus: string;
  employmentType?: string;
  attendanceMode?: string;
  workLocationIds?: string[];
  joiningDate?: string;
  lastWorkingDate?: string;
}
export interface Department {
  id: string;
  name: string;
  headEmployeeId?: string;
  status: string;
}
export interface Shift {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  overnight: boolean;
  timezone?: string;
  graceMinutes: number;
  earlyDepartureGraceMinutes: number;
  minFullDayMinutes?: number;
  minHalfDayMinutes?: number;
  breakPolicy: {
    type?: string;
    paidAllowanceMinutes?: number;
    autoDeductMinutes?: number;
    expectedUnpaidMinutes?: number;
  };
  weeklyOffDays: number[];
  status: string;
}
export interface ShiftAssignment {
  id: string;
  employeeId: string;
  shiftId: string;
  effectiveFrom: string;
  effectiveTo?: string;
}
export interface WorkLocation {
  id: string;
  name: string;
  address?: string;
  latitude: number;
  longitude: number;
  radiusMeters: number;
  status: string;
}
export interface Holiday {
  id: string;
  name: string;
  date: string;
  holidayType: string;
  status: string;
  workLocationId?: string;
}
export interface Tenant {
  id: string;
  name: string;
  slug: string;
  status: string;
  timezone: string;
  workweek: number[];
  settings?: {
    attendance?: {
      requireGeofence?: boolean;
      maxAccuracyMeters?: number;
      allowSelfApproval?: boolean;
      allowGpsExceptions?: boolean;
      requirePhoto?: boolean;
      maxOpenSessionHours?: number;
    };
  };
}
export interface DayRow {
  id: string;
  employeeId: string;
  workDate: string;
  status: string;
  firstCheckIn?: string;
  lastCheckOut?: string;
  workedMinutes: number;
  breakMinutes: number;
  lateMinutes: number;
  earlyDepartureMinutes: number;
  overtimeMinutes: number;
  isOpen?: boolean;
  correctionStatus?: string;
  employee?: { id: string; employeeCode: string; firstName: string; lastName: string };
}
export interface Correction {
  id: string;
  employeeId: string;
  workDate: string;
  requestedChanges?: { checkIn?: string; checkOut?: string };
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  reviewComment?: string;
  createdAt?: string;
}
export interface ExceptionReq {
  id: string;
  employeeId: string;
  eventType: string;
  occurredAt: string;
  failure?: string;
  distanceMeters?: number;
  mockLocationDetected?: boolean;
  employeeReason?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  reviewComment?: string;
}
export interface Dashboard {
  workDate: string;
  timezone: string;
  scope: 'ALL' | 'TEAM';
  headcount: number;
  today: Record<
    | 'present'
    | 'halfDay'
    | 'absent'
    | 'onLeave'
    | 'holiday'
    | 'weeklyOff'
    | 'incomplete'
    | 'workingNow'
    | 'lateToday'
    | 'notYetIn'
    | 'unscheduled',
    number
  >;
  trend: { date: string; present: number; halfDay: number; absent: number; late: number }[];
  pending: { corrections: number; exceptions: number } | null;
}
export interface SummaryRow {
  employeeId: string;
  employeeCode: string;
  name: string;
  department?: string;
  present: number;
  halfDay: number;
  absent: number;
  onLeave: number;
  holiday: number;
  weeklyOff: number;
  incomplete: number;
  lateDays: number;
  lateMinutes: number;
  earlyDepartureDays: number;
  workedMinutes: number;
  overtimeMinutes: number;
}

export interface LeaveType {
  id: string;
  name: string;
  code: string;
  paid: boolean;
  annualAllowanceDays: number;
  allowHalfDay: boolean;
  status: string;
}
export interface LeaveRequest {
  id: string;
  employeeId: string;
  employee?: { id: string; employeeCode: string; firstName: string; lastName: string };
  leaveTypeId: string;
  leaveType?: { name: string; code: string };
  startDate: string;
  endDate: string;
  halfDay: boolean;
  halfDaySession?: string;
  days: number;
  status: string;
  reason?: string;
  reviewComment?: string;
  createdAt: string;
}
export interface LeaveBalance {
  leaveTypeId: string;
  name: string;
  code: string;
  paid: boolean;
  year: number;
  allowanceDays: number | null;
  approvedDays: number;
  pendingDays: number;
  remainingDays: number | null;
}
export interface EmployeeDocument {
  id: string;
  employeeId: string;
  category: string;
  title: string;
  fileName: string;
  contentType: string;
  sizeBytes: number;
  status: string;
  visibleToEmployee: boolean;
  createdAt: string;
}
export interface AuditEntry {
  id: string;
  createdAt: string;
  action: string;
  entityType?: string;
  entityId?: string;
  actorEmail?: string;
  reason?: string;
  before?: unknown;
  after?: unknown;
  requestId?: string;
}
