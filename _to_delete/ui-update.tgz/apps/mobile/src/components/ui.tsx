import type { ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type TextInputProps,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme, type Theme } from '@/theme';

export function Screen({
  children,
  onRefresh,
  refreshing,
  padded = true,
}: {
  children: ReactNode;
  onRefresh?: () => void;
  refreshing?: boolean;
  padded?: boolean;
}) {
  const t = useTheme();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top', 'left', 'right']}>
      <ScrollView
        contentContainerStyle={[padded && { padding: 16, gap: 12 }, { paddingBottom: 32 }]}
        keyboardShouldPersistTaps="handled"
        refreshControl={
          onRefresh ? <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} /> : undefined
        }
      >
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function Card({ children }: { children: ReactNode }) {
  const t = useTheme();
  return (
    <View style={[s.card, { backgroundColor: t.card, borderColor: t.border }]}>{children}</View>
  );
}

export function H1({ children }: { children: ReactNode }) {
  return (
    <Text style={[s.h1, { color: useTheme().text }]} accessibilityRole="header">
      {children}
    </Text>
  );
}
export function Body({
  children,
  muted,
  small,
  bold,
}: {
  children: ReactNode;
  muted?: boolean;
  small?: boolean;
  bold?: boolean;
}) {
  const t = useTheme();
  return (
    <Text
      style={{
        color: muted ? t.muted : t.text,
        fontSize: small ? 13 : 15,
        fontWeight: bold ? '600' : '400',
      }}
    >
      {children}
    </Text>
  );
}

type Variant = 'primary' | 'secondary' | 'danger';
export function Button({
  title,
  onPress,
  variant = 'primary',
  loading,
  disabled,
  accessibilityHint,
}: {
  title: string;
  onPress: () => void;
  variant?: Variant;
  loading?: boolean;
  disabled?: boolean;
  accessibilityHint?: string;
}) {
  const t = useTheme();
  const bg = variant === 'primary' ? t.primary : variant === 'danger' ? t.danger : t.card;
  const fg = variant === 'secondary' ? t.text : variant === 'danger' ? '#fff' : t.primaryText;
  const off = disabled || loading;
  return (
    <Pressable
      onPress={onPress}
      disabled={off}
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled: !!off, busy: !!loading }}
      style={({ pressed }) => [
        s.btn,
        {
          backgroundColor: bg,
          borderColor: variant === 'secondary' ? t.border : bg,
          opacity: off ? 0.5 : pressed ? 0.85 : 1,
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <Text style={[s.btnText, { color: fg }]}>{title}</Text>
      )}
    </Pressable>
  );
}

export function Field({
  label,
  error,
  ...rest
}: TextInputProps & { label: string; error?: string }) {
  const t = useTheme();
  return (
    <View style={{ gap: 4 }}>
      <Text style={{ color: t.text, fontWeight: '600', fontSize: 14 }}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        placeholderTextColor={t.muted}
        {...rest}
        style={[
          s.input,
          { color: t.text, backgroundColor: t.card, borderColor: error ? t.danger : t.border },
          rest.multiline && { minHeight: 90, textAlignVertical: 'top' },
        ]}
      />
      {error ? <Text style={{ color: t.danger, fontSize: 13 }}>{error}</Text> : null}
    </View>
  );
}

type Tone = 'danger' | 'success' | 'warn' | 'info';
const toneColors = (t: Theme, tone: Tone) =>
  ({
    danger: [t.danger, t.dangerBg],
    success: [t.success, t.successBg],
    warn: [t.warn, t.warnBg],
    info: [t.info, t.infoBg],
  })[tone] as [string, string];

export function Banner({
  tone,
  children,
  action,
}: {
  tone: Tone;
  children: ReactNode;
  action?: ReactNode;
}) {
  const t = useTheme();
  const [fg, bg] = toneColors(t, tone);
  return (
    <View
      accessibilityRole={tone === 'danger' ? 'alert' : undefined}
      style={[s.banner, { backgroundColor: bg, borderColor: fg }]}
    >
      <Text style={{ color: fg, fontSize: 14 }}>{children}</Text>
      {action}
    </View>
  );
}

export function Badge({ label, tone }: { label: string; tone: Tone | 'neutral' }) {
  const t = useTheme();
  const [fg, bg] = tone === 'neutral' ? [t.muted, t.border] : toneColors(t, tone);
  return <Text style={[s.badge, { color: fg, backgroundColor: bg }]}>{label}</Text>;
}

export const Center = ({ children }: { children: ReactNode }) => (
  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 }}>
    {children}
  </View>
);

export const Loading = () => (
  <Center>
    <ActivityIndicator size="large" accessibilityLabel="Loading" />
  </Center>
);

export function toneForStatus(status?: string | null): Tone | 'neutral' {
  switch (status) {
    case 'PRESENT':
    case 'APPROVED':
      return 'success';
    case 'HALF_DAY':
    case 'PENDING':
    case 'INCOMPLETE':
      return 'warn';
    case 'ABSENT':
    case 'REJECTED':
      return 'danger';
    default:
      return 'neutral';
  }
}

const s = StyleSheet.create({
  card: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 14, padding: 16, gap: 8 },
  h1: { fontSize: 24, fontWeight: '700' },
  btn: {
    minHeight: 48,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  btnText: { fontSize: 16, fontWeight: '600' },
  input: { minHeight: 48, borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, fontSize: 16 },
  banner: { borderWidth: 1, borderRadius: 12, padding: 12, gap: 8 },
  badge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 999,
    fontSize: 12,
    fontWeight: '600',
    overflow: 'hidden',
  },
});
