import { useColorScheme } from 'react-native';

const light = {
  bg: '#f4f6f8',
  card: '#ffffff',
  text: '#101828',
  muted: '#667085',
  border: '#e4e7ec',
  primary: '#1d4ed8',
  primaryText: '#ffffff',
  danger: '#b42318',
  dangerBg: '#fef3f2',
  success: '#067647',
  successBg: '#ecfdf3',
  warn: '#b54708',
  warnBg: '#fffaeb',
  info: '#175cd3',
  infoBg: '#eff8ff',
};
const dark: typeof light = {
  bg: '#0b0f14',
  card: '#151b23',
  text: '#f2f4f7',
  muted: '#98a2b3',
  border: '#2a3441',
  primary: '#5b8def',
  primaryText: '#0b0f14',
  danger: '#f97066',
  dangerBg: '#3b1512',
  success: '#47cd89',
  successBg: '#0b2a1b',
  warn: '#fdb022',
  warnBg: '#33230a',
  info: '#84caff',
  infoBg: '#0f2744',
};
export type Theme = typeof light;
export const useTheme = (): Theme => (useColorScheme() === 'dark' ? dark : light);
