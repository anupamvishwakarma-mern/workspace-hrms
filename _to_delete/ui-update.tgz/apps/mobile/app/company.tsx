import { Pressable } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { Body, Button, Card, H1, Screen } from '@/components/ui';

export default function Company() {
  const { memberships, selectCompany, signOut } = useAuth();
  return (
    <Screen>
      <H1>Choose a company</H1>
      <Body muted>
        Your account belongs to more than one company. You can switch later from Profile.
      </Body>
      {memberships.map((m) => (
        <Pressable
          key={m.tenantId}
          onPress={() => void selectCompany(m.tenantId)}
          accessibilityRole="button"
          accessibilityLabel={`Open ${m.tenantName ?? 'company'}`}
        >
          <Card>
            <Body bold>{m.tenantName ?? m.tenantSlug ?? m.tenantId}</Body>
            <Body muted small>
              {m.roles.join(', ')}
            </Body>
          </Card>
        </Pressable>
      ))}
      <Button title="Sign out" variant="secondary" onPress={() => void signOut()} />
    </Screen>
  );
}
