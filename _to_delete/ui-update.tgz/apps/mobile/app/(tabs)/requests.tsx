import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import {
  Badge,
  Banner,
  Body,
  Button,
  Card,
  H1,
  Loading,
  Screen,
  toneForStatus,
} from '@/components/ui';
import { useMyCorrections, useMyExceptions, useToday } from '@/hooks/queries';
import { userMessage } from '@/lib/errors';
import { EVENT_LABEL, formatTime, formatWorkDate } from '@/lib/format';
import { useTheme } from '@/theme';

type Tab = 'corrections' | 'exceptions';

export default function Requests() {
  const t = useTheme();
  const router = useRouter();
  const [tab, setTab] = useState<Tab>('corrections');
  const corrections = useMyCorrections();
  const exceptions = useMyExceptions();
  const tz = useToday().data?.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
  const q = tab === 'corrections' ? corrections : exceptions;

  return (
    <Screen onRefresh={() => void q.refetch()} refreshing={q.isRefetching}>
      <H1>Requests</H1>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        {(['corrections', 'exceptions'] as const).map((k) => (
          <Pressable
            key={k}
            onPress={() => setTab(k)}
            accessibilityRole="tab"
            accessibilityState={{ selected: tab === k }}
            style={{
              flex: 1,
              minHeight: 44,
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: 10,
              backgroundColor: tab === k ? t.primary : t.card,
              borderWidth: 1,
              borderColor: t.border,
            }}
          >
            <Text style={{ color: tab === k ? t.primaryText : t.text, fontWeight: '600' }}>
              {k === 'corrections' ? 'Corrections' : 'Location approvals'}
            </Text>
          </Pressable>
        ))}
      </View>

      {tab === 'corrections' ? (
        <Button title="New correction request" onPress={() => router.push('/correction/new')} />
      ) : (
        <Body muted small>
          Location approvals are created from the Today tab when GPS cannot confirm your position.
        </Body>
      )}

      {q.isPending ? <Loading /> : null}
      {q.isError ? <Banner tone="danger">{userMessage(q.error)}</Banner> : null}

      {tab === 'corrections' && corrections.data ? (
        corrections.data.length === 0 ? (
          <Body muted>No correction requests.</Body>
        ) : (
          corrections.data.map((c) => (
            <Card key={c.id}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Body bold>{formatWorkDate(c.workDate)}</Body>
                <Badge label={c.status} tone={toneForStatus(c.status)} />
              </View>
              <Body small muted>
                In {formatTime(c.requestedChanges?.checkIn, tz)} · Out{' '}
                {formatTime(c.requestedChanges?.checkOut, tz)}
              </Body>
              <Body small>{c.reason}</Body>
              {c.reviewComment ? (
                <Body small muted>
                  Reviewer: {c.reviewComment}
                </Body>
              ) : null}
            </Card>
          ))
        )
      ) : null}

      {tab === 'exceptions' && exceptions.data ? (
        exceptions.data.length === 0 ? (
          <Body muted>No location approval requests.</Body>
        ) : (
          exceptions.data.map((x) => (
            <Card key={x.id}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Body bold>
                  {EVENT_LABEL[x.eventType]} · {formatTime(x.occurredAt, tz)}
                </Body>
                <Badge label={x.status} tone={toneForStatus(x.status)} />
              </View>
              {x.employeeReason ? <Body small>{x.employeeReason}</Body> : null}
              {x.reviewComment ? (
                <Body small muted>
                  Reviewer: {x.reviewComment}
                </Body>
              ) : null}
            </Card>
          ))
        )
      ) : null}
    </Screen>
  );
}
