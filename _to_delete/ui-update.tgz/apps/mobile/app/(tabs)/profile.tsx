import Constants from 'expo-constants';
import { Alert, Pressable, View } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { Badge, Body, Button, Card, H1, Screen } from '@/components/ui';

export default function Profile() {
  const { active, memberships, selectCompany, signOut, email } = useAuth();
  return (
    <Screen>
      <H1>Profile</H1>
      <Card>
        {email ? <Body bold>{email}</Body> : null}
        <Body>{active?.tenantName ?? 'Company'}</Body>
        <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
          {active?.roles.map((r) => (
            <Badge key={r} label={r.replace('_', ' ')} tone="neutral" />
          ))}
        </View>
        <Body muted small>
          Roles shown here are informational. What you can do is decided by the server.
        </Body>
      </Card>

      {memberships.length > 1 ? (
        <Card>
          <Body bold>Switch company</Body>
          {memberships.map((m) => (
            <Pressable
              key={m.tenantId}
              disabled={m.tenantId === active?.tenantId}
              onPress={() => void selectCompany(m.tenantId)}
              accessibilityRole="button"
              accessibilityLabel={`Switch to ${m.tenantName ?? 'company'}`}
              style={{ paddingVertical: 10 }}
            >
              <Body bold={m.tenantId === active?.tenantId}>
                {m.tenantName ?? m.tenantId}
                {m.tenantId === active?.tenantId ? ' (current)' : ''}
              </Body>
            </Pressable>
          ))}
        </Card>
      ) : null}

      <Card>
        <Body bold>Your location and privacy</Body>
        <Body small muted>
          This app reads your location once, only when you check in, check out or start/end a break,
          to verify you are at your work location. It never tracks you in the background. Location
          is a signal reviewed together with other information; it does not by itself prove where
          you were.
        </Body>
      </Card>

      <Button
        title="Sign out"
        variant="secondary"
        onPress={() =>
          Alert.alert('Sign out?', 'You will need to sign in again.', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Sign out', style: 'destructive', onPress: () => void signOut() },
          ])
        }
      />
      <Body muted small>
        Version {Constants.expoConfig?.version ?? '0.1.0'}
      </Body>
    </Screen>
  );
}
