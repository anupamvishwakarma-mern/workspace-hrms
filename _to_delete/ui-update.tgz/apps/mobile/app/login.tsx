import { zodResolver } from '@hookform/resolvers/zod';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { Banner, Body, Button, Card, Field, H1, Screen } from '@/components/ui';
import { userMessage } from '@/lib/errors';
import { loginSchema, type LoginForm } from '@/lib/forms';

export default function Login() {
  const { signIn } = useAuth();
  const [error, setError] = useState<string>();
  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const submit = handleSubmit(async (v) => {
    setError(undefined);
    try {
      await signIn(v.email.trim(), v.password);
    } catch (e) {
      setError(userMessage(e));
    }
  });

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Screen>
        <H1>Sign in</H1>
        <Body muted>Use the work account your company set up for you.</Body>
        <Card>
          {error ? <Banner tone="danger">{error}</Banner> : null}
          <Controller
            control={control}
            name="email"
            render={({ field }) => (
              <Field
                label="Email"
                value={field.value}
                onChangeText={field.onChange}
                onBlur={field.onBlur}
                error={errors.email?.message}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                textContentType="username"
                autoComplete="email"
              />
            )}
          />
          <Controller
            control={control}
            name="password"
            render={({ field }) => (
              <Field
                label="Password"
                value={field.value}
                onChangeText={field.onChange}
                onBlur={field.onBlur}
                error={errors.password?.message}
                secureTextEntry
                autoCapitalize="none"
                textContentType="password"
                autoComplete="password"
                onSubmitEditing={() => void submit()}
              />
            )}
          />
          <Button title="Sign in" onPress={() => void submit()} loading={isSubmitting} />
        </Card>
      </Screen>
    </KeyboardAvoidingView>
  );
}
