import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider, useAuth } from '@/auth/AuthProvider';
import { Body, Button, Center, H1, Loading } from '@/components/ui';
import { useAppStateFocus } from '@/hooks/queries';
import { ApiError } from '@/lib/errors';

function Gate() {
  const { status, signOut, retry } = useAuth();
  useAppStateFocus();
  if (status === 'loading') return <Loading />;
  if (status === 'offline')
    return (
      <Center>
        <H1>Cannot reach the server</H1>
        <Body muted>You are still signed in. Check your connection and try again.</Body>
        <Button title="Try again" onPress={retry} />
      </Center>
    );
  if (status === 'noAccess')
    return (
      <Center>
        <H1>No company access</H1>
        <Body muted>
          Your account is not an active member of any company. Contact your HR administrator.
        </Body>
        <Button title="Sign out" variant="secondary" onPress={() => void signOut()} />
      </Center>
    );
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Protected guard={status === 'ready'}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen
          name="correction/new"
          options={{ presentation: 'modal', headerShown: true, title: 'Request correction' }}
        />
      </Stack.Protected>
      <Stack.Protected guard={status === 'signedOut'}>
        <Stack.Screen name="login" />
      </Stack.Protected>
      <Stack.Protected guard={status === 'needsCompany'}>
        <Stack.Screen name="company" />
      </Stack.Protected>
    </Stack>
  );
}

export default function RootLayout() {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            retry: (count, err) =>
              !(err instanceof ApiError && err.status >= 400 && err.status < 500) && count < 2,
          },
        },
      }),
  );
  return (
    <SafeAreaProvider>
      <QueryClientProvider client={client}>
        <AuthProvider>
          <StatusBar style="auto" />
          <Gate />
        </AuthProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}
